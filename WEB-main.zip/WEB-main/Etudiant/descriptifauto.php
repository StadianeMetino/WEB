<?php
include '../connexion.php';
session_start();

$code_user = $_SESSION['CODE_USER'];

if (!isset($_SESSION['CODE_USER']) || !isset($_SESSION['Status']) || $_SESSION['Status'] != 'etudiant') 
{
header('Location: ../login/login.php');
}


$id_stage = $_GET["offreStage"];
$sqlOffres = "SELECT o.*, e.Nom as entreprise, l.* FROM offre_de_stage o, entreprise e, localité l WHERE o.NumSIRET = e.NumSIRET AND o.id_localite = l.id_localité and id_stage = $id_stage";
$resultOffres = $ma_connexion->query($sqlOffres);

$Nom = "";
$Durée = "";
$Rémuneration = "";
$DatePublication = "";
$NbPlaces = "";
$Description = "";
$DateDebut = "";
$DateFin = "";
$entreprise = "";
$NomPays = "";
$NomVille = "";


while ($row = $resultOffres->fetch_assoc()) {

    $Nom = $row['Nom'];
    $Durée = $row['Durée'];
    $Rémuneration = $row['Rémuneration'];
    $DatePublication = $row['DatePublication'];
    $NbPlaces = $row['NbPlaces'];
    $Description = $row['Description'];
    $DateDebut = $row['DateDebut'];
    $DateFin = $row['DateFin'];
    $entreprise = $row['entreprise'];
    $NomPays = $row['NomPays'];
    $NomVille = $row['NomVille'];

}


if (isset($_POST['postuler']) && isset($_SESSION['CODE_USER'])) {

    // Récupérer l'ID de l'utilisateur connecté
    $user_id = $_SESSION['CODE_USER'];

    // Récupérer l'ID de l'offre à laquelle l'utilisateur postule
    $id_stage = $_POST['id_stage'];

    // Vérifier si l'utilisateur a déjà postulé à cette offre
    $check_query = "SELECT COUNT(*) AS count FROM user_applications WHERE id_etudiant = ? AND id_stage = ?";
    $check_stmt = $ma_connexion->prepare($check_query);
    $check_stmt->bind_param("ii", $user_id, $id_stage);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    $row = $check_result->fetch_assoc();

    if ($row['count'] > 0) {
        echo "Vous avez déjà postulé à cette offre.";
    } else {
        // Insertion d'un nouveau enregistrement de candidature
        $insert_query = "INSERT INTO user_applications (id_etudiant, id_stage, cv_path, lettre_motivation_path) VALUES (?, ?, ?, ?)";
        $insert_stmt = $ma_connexion->prepare($insert_query);
        $insert_stmt->bind_param("iiss", $user_id, $id_stage, $cv_path, $lettre_motivation_path);

        // Récupérer les chemins des fichiers CV et lettre de motivation
        $cv_path = "";
        $lettre_motivation_path = "";
        if (isset($_FILES['cv']) && isset($_FILES['lettre_motivation'])) {
            $cv_file = $_FILES['cv'];
            $lettre_motivation_file = $_FILES['lettre_motivation'];

            // Créer un dossier pour l'utilisateur s'il n'existe pas déjà
            $user_folder = "../ressources_etudiants/user_" . $user_id . "-offre_" . $id_stage;
            if (!file_exists($user_folder)) {
                mkdir($user_folder, 0777, true);
            }

            // Définir les chemins de destination pour les fichiers téléchargés
            $cv_path = $user_folder . "/" . $cv_file['name'];
            $lettre_motivation_path = $user_folder . "/" . $lettre_motivation_file['name'];

            // Déplacer les fichiers téléchargés dans le dossier de l'utilisateur
            move_uploaded_file($cv_file['tmp_name'], $cv_path);
            move_uploaded_file($lettre_motivation_file['tmp_name'], $lettre_motivation_path);
        }

        // Exécuter la requête d'insertion
        if ($insert_stmt->execute()) {
        } else {
            echo "Erreur lors de la soumission de la candidature.";
        }
    }
}





if(isset($_POST['Quitter']))
{  
  
 // Inialize session
  session_start();
// Delete certain session
  unset($_SESSION['CODE_USER']);
  unset($_SESSION['Status']);
  // Delete all session variables
  // session_destroy();
  session_destroy();
 // Jump to login page
header('Location: ../login/login.php');
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Gestion des offres | Descriptif offre</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
  <style type="text/css">
    .competence-tag {
        display: inline-block;
        padding: 5px 10px;
        margin-right: 10px;
        margin-bottom: 10px;
        border-radius: 20px;
        background-color: #3c8dbc;
        color: #fff;
        font-size: 14px;
    }

    .competence-tag.programmation {
        background-color: #007bff;
        color: #fff;
    }

    .competence-tag.communication {
        background-color: #28a745;
        color: #fff;
    }

    .competence-tag.analyse {
        background-color: #ffc107;
        color: #333;
    }

    .competence-tag.management {
        background-color: #dc3545;
        color: #fff;
    }

  </style>
</head>

<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

  <header class="main-header">
    <nav class="navbar navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <a href="../index.php" class="navbar-brand"><b>Gestion des </b>Offres</a>
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
            <i class="fa fa-bars"></i>
          </button>
        </div>

        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#">Fiche descriptive Offre <span class="sr-only">(current)</span></a></li>
            <li><a href="Espace-Etudiant.php">Espace Etudiant</a></li>
          </ul>
        </div>

        <div class="collapse navbar-collapse pull-right" id="navbar-collapse">
          <ul class="nav navbar-nav">
            <li>
              <form id="quitterForm" method="post">
                <button type="submit" name="Quitter" class="btn btn-primary">Quitter</button>
              </form>
            </li>
          </ul>
        </div>


      </div>
      <!-- /.container-fluid -->
    </nav>
  </header>
  <!-- Full Width Column -->
  <div class="content-wrapper">
    <div class="container">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="pull-right">

            <?php

                if (isset($_SESSION['CODE_USER'])) {
                    $user_id = $_SESSION['CODE_USER'];

                    // Check if the user has already applied to this offer
                    $check_query = "SELECT applied_at FROM user_applications WHERE id_etudiant = ? AND id_stage = ?";
                    $check_stmt = $ma_connexion->prepare($check_query);
                    $check_stmt->bind_param("ii", $user_id, $id_stage);
                    $check_stmt->execute();
                    $check_result = $check_stmt->get_result();

                    if ($check_result->num_rows > 0) {
                        // User has already applied
                        $row = $check_result->fetch_assoc();
                        $applied_date = date('Y-m-d', strtotime($row['applied_at']));
                        echo "<button type='button' class='btn btn-info' disabled style='color:#000'>Déjà postulé (Postulé le $applied_date)</button>";
                    } else {
                        echo '<button type="button" onclick="openPostulerModal()" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#postulerModal">Postuler</button>';
                    }
                }


            ?>


            <div class="modal fade in" id="postulerModal" tabindex="-1" aria-labelledby="postulerModal" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
            <form method="post" enctype="multipart/form-data">

            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span></button>
            <h1 class="modal-title fs-5" id="postulerModal">Postuler</h1>
            </div>

            <div class="modal-body">
                <!-- Formulaire pour postuler -->
                <input type="hidden" name="id_stage" value="<?php echo $id_stage; ?>">

                <!-- Champ pour le CV -->
                <div class="mb-3">
                    <label for="cv" class="form-label">CV</label>
                    <input type="file" class="form-control" id="cv" name="cv" accept=".pdf,.doc,.docx" required>
                </div>

                <!-- Champ pour la lettre de motivation -->
                <div class="mb-3">
                    <label for="lettre_motivation" class="form-label">Lettre de motivation</label>
                    <input type="file" class="form-control" id="lettre_motivation" name="lettre_motivation" accept=".pdf,.doc,.docx" required>
                </div>
                    
            </div>

            <div class="modal-footer">
            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
            <button type="submit" name="postuler" value="postuler" class="btn btn-primary">Envoyer</button>
            </div>

            </form>

            </div>
            </div>
            </div>








        </div>
        <h1>
          Fiche descriptive Offre
          <small>détails :</small>
        </h1>
      </section>

      <!-- Main content -->
      <section class="content">


        <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li class="active"><a href="#Description" data-toggle="tab">Description</a></li>                      
                <li><a href="#competence" data-toggle="tab">Compétences</a></li>
            </ul>

            <div class="tab-content">

              <div class="tab-pane active" id="Description">
                <form class="form-horizontal">

                    <div class="offre-details">
                        <h1 style="color:#3c8dbc"><?php echo $Nom; ?></h1>
                        <hr>
                        <div class="row">
                            <div class="col-md-6">
                                <h3 style="color:#3c8dbc">Informations sur l'offre :</h3>
                                <ul>
                                    <li><strong>Durée :</strong> <?php echo $Durée; ?></li>
                                    <li><strong>Rémuneration :</strong> <?php echo $Rémuneration . "€"; ?></li>
                                    <li><strong>Date de publication :</strong> <?php echo $DatePublication; ?></li>
                                    <li><strong>Nombre de places :</strong> <?php echo $NbPlaces; ?></li>
                                    <li><strong>Date de début :</strong> <?php echo $DateDebut; ?></li>
                                    <li><strong>Date de fin :</strong> <?php echo $DateFin; ?></li>
                                </ul>
                            </div>
                            <div class="col-md-6">
                                <h3 style="color:#3c8dbc">Entreprise :</h3>
                                <ul>
                                    <li><strong>Nom :</strong> <?php echo $entreprise; ?></li>
                                    <li><strong>Pays :</strong> <?php echo $NomPays; ?></li>
                                    <li><strong>Ville :</strong> <?php echo $NomVille; ?></li>
                                </ul>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-12">
                                <h3 style="color:#3c8dbc">Description :</h3>
                                <p><?php echo $Description; ?></p>
                            </div>
                        </div>
                    </div>

                </form>

              </div>

              <div class="tab-pane" id="competence">
                <h2 style="color:#3c8dbc">Compétences</h2>
                <div class="competences">
                    <?php
                    // Query to fetch competencies linked to the offer
                    $sql_linked_competencies = "SELECT c.Nom
                                                FROM compétence c
                                                INNER JOIN necessite n ON c.id_competence = n.id_competence
                                                WHERE n.id_stage = ?";
                    $stmt_linked_competencies = $ma_connexion->prepare($sql_linked_competencies);
                    $stmt_linked_competencies->bind_param("i", $id_stage);
                    $stmt_linked_competencies->execute();
                    $result_linked_competencies = $stmt_linked_competencies->get_result();

                    // Check if competencies are found
                    if ($result_linked_competencies->num_rows > 0) {
                        // Loop through the fetched competencies
                        while ($row_linked_competency = $result_linked_competencies->fetch_assoc()) {
                            // Output each competency as a styled tag
                            $competence_name = $row_linked_competency['Nom'];
                            // Utilisation d'une classe CSS différente pour chaque compétence
                            $class = "competence-" . strtolower(str_replace(" ", "-", $competence_name)); // Convertir le nom de la compétence en classe CSS
                            echo "<span class='competence-tag $class'>$competence_name</span>";
                        }
                    } else {
                        // If no competencies are found, display a message
                        echo "<p>Aucune compétence n'est associée à cette offre.</p>";
                    }

                    // Close the database connection
                    $stmt_linked_competencies->close();
                    ?>
                </div>
            </div>


            </div>  


            </div>
        

        <!-- /.box -->
      </section>
      <!-- /.content -->
    </div>
    <!-- /.container -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>Version</b> 3.0.0
      </div>
      <strong>Copyright &copy; 2017-2018 <a href="http://www.facebook.com/mohammeddib3">DAL</a>.</strong>All rights
      reserved.
    </div>
    <!-- /.container -->
  </footer>
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../dist/js/demo.js"></script>

<script type="text/javascript">
    function openPostulerModal() {
        // Open modal
        $('#postulerModal').modal('show');
    }


</script>

</body>
</html>
