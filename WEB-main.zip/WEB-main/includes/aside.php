  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="../images/Admin_PIC.png"  alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $prenom." ".$nom ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i>En ligne</a>
        </div>
      </div>
      

<ul class="sidebar-menu">
        <li class="header">ADMINISTRATEUR</li>
        <li id="profil"><a href="../Profil/Profil.php"><i class="fa fa-user"></i><span>Profil</span></a></li>
        <li id="LesOffres"><a href="../Profil/offres.php"><i class="fa fa-archive"></i> <span>Les offres</span></a></li>
        <li id="LesEntreprises"><a href="../Profil/entreprises.php"><i class="fa fa-archive"></i> <span>Les entreprises</span></a></li>
        <li id="LesUtilisateurs"><a href="../Profil/utilisateurs.php"><i class="fa fa-archive"></i> <span>Les utilisateurs</span></a></li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>