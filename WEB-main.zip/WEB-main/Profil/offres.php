<?php
include '../connexion.php';
?>

<?php
session_start();
$code_user = $_SESSION['CODE_USER'];

if (!isset($_SESSION['CODE_USER']) || !isset($_SESSION['Status']) || $_SESSION['Status'] != 'admin') 
{
header('Location: ../login/login.php');
}

  if(isset($_SESSION['CODE_USER']) && $code_user != null){

    $req=($bd->query('SELECT * FROM utilisateurs WHERE id_etudiant="'.$code_user.'" '));
    $sqlOffres = "SELECT o.*, e.Nom as entreprise, l.* FROM offre_de_stage o, entreprise e, localité l WHERE o.NumSIRET = e.NumSIRET AND o.id_localite = l.id_localité";
    $resultOffres = $ma_connexion->query($sqlOffres);

    $ress = $req->fetch();
    $prenom = $ress['Prenom'];
    $nom    = $ress['Nom'];
    $Status    = $ress['Status'];
    $Email    = $ress['Email'];
    $id_PromoAnnee    = $ress['id_PromoAnnee'];

  }
  



if (isset($_POST['action']) && $_POST['action'] == 'add') {
    
    // Retrieve form data
    $nom_offre = $_POST['nom_offre'];
    $duree = $_POST['duree'];
    $remuneration = $_POST['remuneration'];
    $DatePublication = $_POST['datePublication'];
    $NbPlaces = $_POST['nbPlaces'];
    $Description = $_POST['description'];
    $DateDebut = $_POST['dateDebut']; 
    $DateFin = $_POST['dateFin']; 
    $NumSIRET = $_POST['NumSIRET']; 
    $id_localite = $_POST['id_localite']; 

    $sql = "INSERT INTO offre_de_stage (Nom, Durée, Rémuneration, DatePublication, NbPlaces, Description, DateDebut, DateFin, NumSIRET, id_localite) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $ma_connexion->prepare($sql);
    $stmt->bind_param("sddsisssii", $nom_offre, $duree, $remuneration, $DatePublication, $NbPlaces, $Description, $DateDebut, $DateFin, $NumSIRET, $id_localite);
    $stmt->execute();

    $id_stage = $ma_connexion->insert_id;

    // Process the selected competencies
    if (!empty($_POST['compétence'])) {
        // Delete existing associations between the offer and competencies
        $sql_delete_associations = "DELETE FROM necessite WHERE id_stage = ?";
        $stmt_delete_associations = $ma_connexion->prepare($sql_delete_associations);
        $stmt_delete_associations->bind_param("i", $id_stage);
        $stmt_delete_associations->execute();
        $stmt_delete_associations->close();

        // Insert new associations between the offer and competencies
        $competences = $_POST['compétence'];
        foreach ($competences as $id_competence) {
            $sql_insert_association = "INSERT INTO necessite (id_stage, id_competence) VALUES (?, ?)";
            $stmt_insert_association = $ma_connexion->prepare($sql_insert_association);
            $stmt_insert_association->bind_param("ii", $id_stage, $id_competence);
            $stmt_insert_association->execute();
            $stmt_insert_association->close();
        }
    }

    if ($stmt->affected_rows > 0) {
        header("Location: offres.php");
        exit();
    } else {
        echo "Error adding record: " . $ma_connexion->error;
    }

    $stmt->close();

} elseif (isset($_POST['action']) && $_POST['action'] == 'edit' && isset($_POST['id_stage'])) {

    $id_stage = $_POST['id_stage'];
    $nom_offre = $_POST['nom_offre'];
    $duree = $_POST['duree'];
    $remuneration = $_POST['remuneration'];
    $DatePublication = $_POST['datePublication'];
    $NbPlaces = $_POST['nbPlaces'];
    $Description = $_POST['description'];
    $DateDebut = $_POST['dateDebut'];
    $DateFin = $_POST['dateFin'];
    $NumSIRET = $_POST['NumSIRET']; 
    $id_localite = $_POST['id_localite']; 


    $sql = "UPDATE offre_de_stage SET 
            Nom = '$nom_offre',
            Durée = '$duree',
            Rémuneration = '$remuneration',
            DatePublication = '$DatePublication',
            NbPlaces = '$NbPlaces',
            Description = '$Description',
            DateDebut = '$DateDebut',
            DateFin = '$DateFin',
            NumSIRET = '$NumSIRET',
            id_localite = '$id_localite'
            WHERE id_stage = ?"; 

    $stmt = $ma_connexion->prepare($sql);
    $stmt->bind_param("i", $_POST['id_stage']); 
    $stmt->execute();


    // Process the selected competencies
    if (!empty($_POST['compétence'])) {
        // Delete existing associations between the offer and competencies
        $sql_delete_associations = "DELETE FROM necessite WHERE id_stage = ?";
        $stmt_delete_associations = $ma_connexion->prepare($sql_delete_associations);
        $stmt_delete_associations->bind_param("i", $id_stage);
        $stmt_delete_associations->execute();
        $stmt_delete_associations->close();

        // Insert new associations between the offer and competencies
        $competences = $_POST['compétence'];
        foreach ($competences as $id_competence) {
            $sql_insert_association = "INSERT INTO necessite (id_stage, id_competence) VALUES (?, ?)";
            $stmt_insert_association = $ma_connexion->prepare($sql_insert_association);
            $stmt_insert_association->bind_param("ii", $id_stage, $id_competence);
            $stmt_insert_association->execute();
            $stmt_insert_association->close();
        }
    }


    if ($stmt->affected_rows > 0) {
        header("Location: offres.php");
        exit();
    }

    // Close statement
    $stmt->close();
}


if(isset($_POST['deleteOffer']) && isset($_POST['id_stage'])) {

    $id_stage = $_POST['id_stage'];

    $sql = "DELETE FROM offre_de_stage WHERE id_stage = ?";
    $stmt = $ma_connexion->prepare($sql);
    $stmt->bind_param("i", $id_stage);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header("Location: offres.php");
        exit();
    } else {
        echo "Error deleting offer: " . $ma_connexion->error;
    }

    $stmt->close();
}



if(isset($_POST['Quitter']))
{  
  
 // Inialize session
  session_start();
// Delete certain session
  unset($_SESSION['CODE_USER']);
  unset($_SESSION['Status']);
  // Delete all session variables
  // session_destroy();
  session_destroy();
 // Jump to login page
header('Location: ../login/login.php');
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Projet des offres | Profil</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">  
  <link rel="stylesheet" type="text/css" href="../css/ionicons.min.css">  
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
  <script src="../js/jquery.js"></script>
  <link rel="stylesheet" type="text/css" href="../css/sweetalert2.min.css">  
  <link rel="stylesheet" type="text/css" href="../DataTables/datatables.min.css"/>
  <script src="../js/sweetalert2.min.js"></script>

</head>
<body class="sidebar-mini wysihtml5-supported skin-blue">
<div class="wrapper">

<?php include("../includes/header.php"); ?>
<?php include("../includes/aside.php"); ?>



<div class="content-wrapper" style="min-height: 1136.3px;">

<section class="content-header">
<h1>
Offres
</h1>
</section>

<section class="content">

<div class="box">
<div class="box-header with-border">
<h3 class="box-title">offres</h3>
<div class="box-tools pull-right">
<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="" data-original-title="Collapse">
<i class="fa fa-minus"></i></button>
<button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="" data-original-title="Remove">
<i class="fa fa-times"></i></button>
</div>
</div>


<div class="box-body" style="">



<div class="box-body table-responsive no-padding">

<!-- Add button -->
<div class="top-panel pull-right">
    <a href="javascript:void(0);" class="btn btn-primary" onclick="addOffre()">Ajouter une nouvelle offre</a><br><br>
</div>

  <!-- Data list table -->
  <table class="table table-hover" style="width:100%">
      <thead>
          <tr>
              <th>Nom</th>
              <th>Durée</th>
              <th>Rémuneration</th>
              <th>DatePublication</th>
              <th>NbPlaces</th>
              <th>Description</th>
              <th>DateDebut</th>
              <th>DateFin</th>
              <th>Entreprise</th>
              <th>localité</th>
              <th>Action</th>
          </tr>
      </thead>

      <tbody>
        
        <?php
          while ($row = $resultOffres->fetch_assoc()) {
              $description = strlen($row["Description"]) > 20 ? substr($row["Description"], 0, 20) . "..." : $row["Description"];
              echo "<tr>
                      <td>" . $row["Nom"] . "</td>
                      <td>" . $row["Durée"] . "</td>
                      <td>" . $row["Rémuneration"] . "</td>
                      <td>" . $row["DatePublication"] . "</td>
                      <td>" . $row["NbPlaces"] . "</td>
                      <td>" . $description . "</td>
                      <td>" . $row["DateDebut"] . "</td>
                      <td>" . $row["DateFin"] . "</td>
                      <td>" . $row["entreprise"] . "</td>
                      <td>" . $row["NomPays"] . '-' . $row["NomVille"] . "</td>
                      <td>
                          <a href='javascript:void(0);' class='btn btn-warning' onclick='editOffre(" . json_encode($row) . ")'>Edit</a>
                          <form method=\"post\">
                              <input type=\"hidden\" name=\"id_stage\" value=\"" . $row["id_stage"] . "\">
                              <button type=\"submit\" class=\"btn btn-danger\" name=\"deleteOffer\" onclick=\"return confirm('Êtes-vous sûr de vouloir supprimer cette offre?');\">Delete</button>
                          </form>
                      </td>
                    </tr>";
          }
          ?>


      </tbody>


  </table>
</div>

</div>


</div>

</section>

</div>



<div class="modal fade in" id="modalOffre" tabindex="-1" aria-labelledby="addEditOffre" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<form id="offreForm" method="post">

<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">×</span></button>
<h1 class="modal-title fs-5" id="modalOffre">Ajouter/modifier une offre</h1>
</div>

<div class="modal-body">
    <input type="hidden" name="action" id="action" value="add">
    <input type="hidden" name="id_stage" id="id_stage">
        <div class="mb-3">
            <label for="nom_offre" class="form-label">Nom offre</label>
            <input type="text" class="form-control" name="nom_offre" id="nom_offre" placeholder="Enter nom de l'offre" required>
        </div>
        <div class="mb-3">
            <label for="duree" class="form-label">Durée</label>
            <input type="number" class="form-control" name="duree" id="duree" placeholder="Enter duree" required>
        </div>
        <div class="mb-3">
            <label for="remuneration" class="form-label">Rémuneration</label>
            <input type="number" class="form-control" name="remuneration" id="remuneration" placeholder="Enter remuneration" required>
        </div>
        <div class="mb-3">
            <label for="DatePublication" class="form-label">DatePublication</label>
            <input type="date" class="form-control" name="datePublication" id="DatePublication" placeholder="Enter DatePublication" required>
        </div>
        <div class="mb-3">
            <label for="NbPlaces" class="form-label">NbPlaces</label>
            <input type="number" class="form-control" name="nbPlaces" id="NbPlaces" placeholder="Enter NbPlaces" required>
        </div>
        <div class="mb-3">
            <label for="Description" class="form-label">Description</label>
            <textarea type="textarea" class="form-control" name="description" id="Description" placeholder="Enter Description" required></textarea>
        </div>
        <div class="mb-3">
            <label for="DateDebut" class="form-label">DateDebut</label>
            <input type="date" class="form-control" name="dateDebut" id="DateDebut" placeholder="Enter DateDebut" required>
        </div>
        <div class="mb-3">
            <label for="DateFin" class="form-label">DateFin</label>
            <input type="date" class="form-control" name="dateFin" id="DateFin" placeholder="Enter DateFin" required>
        </div>
        <div class="mb-3">
            <label for="NumSIRET" class="form-label">NumSIRET</label>
            <?php
                $sql = "SELECT NumSIRET, Nom FROM entreprise";
                $result = $ma_connexion->query($sql);
                if ($result->num_rows > 0) {
                    echo '<select class="form-control" id="NumSIRET" name="NumSIRET">';
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['NumSIRET'] . "'>" . $row['Nom'] . "</option>";
                    }
                    echo '</select>';
                }
            ?>
        </div>
        <div class="mb-3">
            <label for="id_localite" class="form-label">id_localite</label>
            <?php
                $sql = "SELECT id_localité, NomPays, NomVille FROM localité";
                $result = $ma_connexion->query($sql);
                if ($result->num_rows > 0) {
                    echo '<select class="form-control" id="id_localite" name="id_localite">';
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['id_localité'] . "'>" . $row['NomPays'] . '-' . $row['NomVille'] . "</option>";
                    }
                    echo '</select>';
                }
            ?>
        </div>
        <div class="mb-3">
            <label for="compétence" class="form-label">compétence</label>
            <select multiple id="compétence" name="compétence[]" class="form-control">

            </select>
        </div>

</div>

<div class="modal-footer">
<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
<button type="submit" class="btn btn-primary" id="submitBtn">Enregistrer</button>
</div>

</form>

</div>
</div>
</div>



<footer class="main-footer">
  <div class="pull-right hidden-xs">
  <b>CESI-Ingénieurs</b>
  </div>
  <strong>Copyright &copy; 2023-2024</strong> All rights
  reserved.
</footer>

  
</div>
<!-- ./wrapper -->
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/app.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../dist/js/demo.js"></script>
<script src="../js/sweetalert2.min.js"></script>
<script type="text/javascript" src="../DataTables/datatables.min.js"></script>

<script type="text/javascript">
  

  function addOffre() {

    // Clear previous input values if any
    $('#offreForm')[0].reset();
    $('#id_stage').val(null);

    $('#id_localite').val(null); // Reset id_localite select option
    $('#compétence').val(null); // Reset compétence select option
    $('#NumSIRET').val(null); // Reset NumSIRET select option

    fetchCompetencies("ALL");

    $('#action').val('add'); // Set action to 'add' for adding new entry
    
    // Open modal
    $('#modalOffre').modal('show');

  }


  function editOffre(rowData) {
      var { id_stage, Nom, Durée, Rémuneration, DatePublication, NbPlaces, Description, DateDebut, DateFin, NumSIRET, id_localité  } = rowData;
      $('#id_stage').val(id_stage);
      $('#nom_offre').val(Nom);
      $('#duree').val(Durée);
      $('#remuneration').val(Rémuneration);
      $('#DatePublication').val(DatePublication);
      $('#NbPlaces').val(NbPlaces);
      $('#Description').val(Description);
      $('#DateDebut').val(DateDebut);
      $('#DateFin').val(DateFin);

      // Set selected option based on NumSIRET
      $('#NumSIRET option').each(function() {
        if ($(this).val() == NumSIRET) {
          $(this).prop('selected', true);
        }
      });

      // Set selected option based on id_localite
      $('#id_localite option').each(function() {
        if ($(this).val() == id_localité) {
           $(this).prop('selected', true);
        }
      });

      fetchCompetencies(id_stage);

      $('#action').val('edit');
      // Open the modal
      $('#modalOffre').modal('show');
  }


    function fetchCompetencies(id_stage) {
        $.ajax({
            url: 'fetch_competencies.php',
            method: 'GET',
            data: { id_stage: id_stage },
            success: function(response) {
                $('#compétence').html(response);
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
    }


</script>


</body>
</html>
