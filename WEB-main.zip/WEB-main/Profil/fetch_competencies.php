<?php

include '../connexion.php';


if (isset($_GET['id_stage'])) {

    if($_GET['id_stage'] == "ALL"){

        // Fetch all competencies from the database
        $sql_all_competencies = "SELECT id_competence, Nom FROM compétence";
        $result_all_competencies = $ma_connexion->query($sql_all_competencies);

        if ($result_all_competencies->num_rows > 0) {
            // Start building the options for the select element
            $options_html = '';

            // Loop through all competencies
            while ($row_competency = $result_all_competencies->fetch_assoc()) {
                $id_competence = $row_competency['id_competence'];
                $nom_competence = $row_competency['Nom'];

                // Append the option to the HTML string
                $options_html .= "<option value='$id_competence'>$nom_competence</option>";
            }

            // Output the options for the select element
            echo $options_html;
        } else {
            echo "<option>No competencies found</option>";
        }

    }else{

        $id_stage = $_GET['id_stage'];
        // Fetch all competencies from the database
        $sql_all_competencies = "SELECT id_competence, Nom FROM compétence";
        $result_all_competencies = $ma_connexion->query($sql_all_competencies);

        if ($result_all_competencies->num_rows > 0) {
            // Start building the options for the select element
            $options_html = '';

            // Fetch competencies linked to the specific offer
            $sql_linked_competencies = "SELECT c.id_competence
                                        FROM compétence c
                                        INNER JOIN necessite n ON c.id_competence = n.id_competence
                                        WHERE n.id_stage = ?";
            $stmt_linked_competencies = $ma_connexion->prepare($sql_linked_competencies);
            $stmt_linked_competencies->bind_param("i", $id_stage);
            $stmt_linked_competencies->execute();
            $result_linked_competencies = $stmt_linked_competencies->get_result();

            // Create an array to store IDs of selected competencies for the offer
            $selected_competencies = array();
            while ($row_linked_competency = $result_linked_competencies->fetch_assoc()) {
                $selected_competencies[] = $row_linked_competency['id_competence'];
            }

            // Loop through all competencies
            while ($row_competency = $result_all_competencies->fetch_assoc()) {
                $id_competence = $row_competency['id_competence'];
                $nom_competence = $row_competency['Nom'];

                // Check if the competency is selected for the offer
                $is_selected = in_array($id_competence, $selected_competencies) ? 'selected' : '';

                // Append the option to the HTML string
                $options_html .= "<option value='$id_competence' $is_selected>$nom_competence</option>";
            }

            // Output the options for the select element
            echo $options_html;
        } else {
            echo "<option>No competencies found</option>";
        }

        $stmt_linked_competencies->close();
    }

} else {
    echo "<option>Invalid request</option>";
}

// Close the database connection
$ma_connexion->close();
?>