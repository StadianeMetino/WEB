<?php
include '../connexion.php';
?>

<?php
session_start();
$code_user = $_SESSION['CODE_USER'];

if (!isset($_SESSION['CODE_USER']) || !isset($_SESSION['Status']) || $_SESSION['Status'] != 'admin') 
{
header('Location: ../login/login.php');
}

  if(isset($_SESSION['CODE_USER']) && $code_user != null){
    
    $req=($bd->query('SELECT * FROM utilisateurs WHERE id_etudiant="'.$code_user.'" '));
    $ress = $req->fetch();
    $prenom = $ress['Prenom'];
    $nom    = $ress['Nom'];
    $Status    = $ress['Status'];
    $Email    = $ress['Email'];
    $id_PromoAnnee    = $ress['id_PromoAnnee'];

  }
  

if(isset($_POST['Modifier1']))
  {

    $code_uni=$_POST['universite'];
    $code_etab=$_POST['etablissement'];
    $code_dept=$_POST['departement'];
    $nom=$_POST['nom'];
    $Pseudo=$_POST['username'];
    $prenom=$_POST['prenom'];
    $grade=$_POST['grade'];
    $spec=$_POST['Specialite'];
    $email=$_POST['email'];
    $tele=$_POST['tele'];

    $sql= "UPDATE `coordonateur_filiere` SET `CODE_ETA`=$code_etab,`CODE_DEPT`=$code_dept,`PSEUDO`='".$Pseudo."',`NOM_COR_FIL`='".$nom."',`PRENOM_COR_FIL`='".$prenom."',`SPCIALITE_COR_FIL`='".$spec."',`GRADE_COR_FIL`='".$grade."',`EMAIL_COR_FIL`='".$email."',`TELE_COR_FIL`='".$tele."' WHERE `CODE_COR_FIL`='".$rest."' ";
      $result=mysqli_query($ma_connexion,$sql);
      echo "<meta http-equiv='refresh' content='0' />";
  }



if(isset($_POST['Quitter']))
{  
  
 // Inialize session
  session_start();
// Delete certain session
  unset($_SESSION['CODE_USER']);
  unset($_SESSION['Status']);
  // Delete all session variables
  // session_destroy();
  session_destroy();
 // Jump to login page
header('Location: ../login/login.php');
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Projet des offres | Profil</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">  
  <link rel="stylesheet" type="text/css" href="../css/ionicons.min.css">  
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
  <script src="../js/jquery.js"></script>
  <link rel="stylesheet" type="text/css" href="../css/sweetalert2.min.css">  
  <script src="../js/sweetalert2.min.js"></script>
  <script type="text/javascript">
  $(function() {
    $('#profil').addClass("active");
  });
</script>
</head>
<body class="sidebar-mini wysihtml5-supported skin-blue">
<div class="wrapper">

<?php include("../includes/header.php"); ?>
<?php include("../includes/aside.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Profil de l'utilisateur
      </h1>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">

        <div class="col-md-3">
          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive " src="../images/Admin_PIC.png" alt="User profile picture">

              <h3 class="profile-username text-center"><?php echo $prenom." ".$nom ?></h3>

              <p class="text-muted text-center"><?php echo $Status ?></p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Téléphone</b> <a class="pull-right">0745378452</a>
                </li>
              </ul>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

          <!-- About Me Box -->
          <div class="box box-primary">
            <div class="box-header with-border">
              <h3 class="box-title">Sur Moi</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <strong><i class="fa fa-book margin-r-5"></i>Niveau</strong>

              <p class="text-muted">
               A2 INFO
              </p>

              <hr>

              <strong><i class="fa fa-institution margin-r-5"></i>Centre</strong>

              <p class="text-muted">Nancy</p>

              <hr>

              <strong><i class="fa fa-institution margin-r-5"></i>Etablissement</strong>

              <p class="text-muted">CESI</p>

              <hr>

              <strong><i class="fa fa-pencil margin-r-5"></i>Compétances</strong>

              <p>
                <span class="label label-danger">HTML</span>
                <span class="label label-danger">Ajax</span>
                <span class="label label-success">Coding</span>
                <span class="label label-info">Javascript</span>
                <span class="label label-warning">PHP</span>
                <span class="label label-primary">Jquery</span>
              </p>

            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
        <div class="col-md-9">
          <div class="nav-tabs-custom">
            <ul class="nav nav-tabs">
              <li><a href="#timeline" data-toggle="tab">Image-Profil</a></li>
              <li><a href="#settings" data-toggle="tab">parametres-profil</a></li>
              <li><a href="#password" data-toggle="tab">Mot-de-passe-profil</a></li>
            </ul>
            <div class="tab-content">

              <div class="active tab-pane" id="activity">
                <div class="row">
                <div class="col-lg-3 col-xs-6">
          <!-- small box -->
        </div>
      </div>
       
        </div>
              <!-- /.tab-pane -->
 <div class="tab-pane" id="timeline">

<div class="row">
<div class="col-sm-6 col-md-4">                             
<img src="../images/Admin_PIC.png" alt="" class="img-rounded img-responsive" >

<form method="post" enctype="multipart/form-data">
<input class="form-control" type="file" name="fileToUpload">
<input type="submit" value="Upload Image" name="submitimage">
</form>
<?php
                                            if(isset($_POST["submitimage"])) {
                                                $errors= array();
                                                $file_name = $_FILES['fileToUpload']['name'];
                                                //$file_size =$_FILES['fileToUpload']['size'];
                                                $file_tmp =$_FILES['fileToUpload']['tmp_name'];
                                                //$file_type=$_FILES['fileToUpload']['type'];
                                                
                                                //$expensions= array("jpeg","jpg","png");
                                                
                                                //move_uploaded_file($file_tmp,"images/".$file_name);
                                                if ( $Etat =="coordonateur filiere" ) 
                                                {
                                                    try{
                                                $sql = "update coordonateur_filiere set IMAGE_COR_FIL = '".$file_name."'
                                                     WHERE  CODE_COR_FIL = '".$rest."'" ; 
                                                    $bd->exec($sql);
                                                    move_uploaded_file($file_tmp,"../images/".$file_name);
                                                    echo "<meta http-equiv='refresh' content='0' />";
                                                }catch(PDOException $e)
                                                    {
                                                    echo $sql . "<br>" . $e->getMessage();
                                                    }
                                                }
                                                else if ( $Etat =="Coordonnateur Module" ) 
                                                {
                                                    try{
                                                $sql = "update coordonateur_module set IMAGE_COR_MODU = '".$file_name."'
                                                     WHERE  CODE_COR_MODU = '".$rest."'" ; 
                                                    $bd->exec($sql);
                                                    move_uploaded_file($file_tmp,"../images/".$file_name);
                                                    echo "<meta http-equiv='refresh' content='0' />";
                                                }catch(PDOException $e)
                                                    {
                                                    echo $sql . "<br>" . $e->getMessage();
                                                    }
                                                }
                                                else{
                                                    try{
                                                $sql = "update enseignant set IMAGE_ENS = '".$file_name."'
                                                     WHERE CODE_ENS = '".$rest."'" ; 
                                                    $bd->exec($sql);
                                                    move_uploaded_file($file_tmp,"../images/".$file_name);
                                                    echo "<meta http-equiv='refresh' content='0' />";
                                                }catch(PDOException $e)
                                                    {
                                                    echo $sql . "<br>" . $e->getMessage();
                                                    }
                                                    
                                                }
                                                    
                                                
                                                    
                                                //echo "name of file ".$file_name." file size ".$file_size." file temp ".$file_tmp." file type ".$file_type." file extention ".$file_ext;
                                            }
                                        ?>
 </div>
<div class="col-sm-6 col-md-8">
                                <h3><?php echo $Status ?></h3>
                                <p>
                                    <i class="fa fa-chevron-circle-right "></i> Nom : <?php echo $nom ?>
                                    <br />
                                    <i class="fa fa-chevron-circle-right "></i> prénom :  <?php echo $prenom ?> 
                                    <br />
                                    <i class="fa fa-check-square"></i> nom d'utilisateur :  <?php echo  $nom . $prenom ;?>
</p>
 </div>
 </div>
</div>
              <!-- /.tab-pane -->

              <div class="tab-pane" id="settings">
                <form class="form-horizontal" action="" method="POST">
                  <div class="form-group">
                            <label for="inputEmail3" class="col-sm-3 control-label">Université</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="universite" id="universite">                       
                                    <option value="Département" selected>Université</option>
                                    </select>
                                </div>
                  </div>
                  <div class="form-group">
                            <label for="inputEmail3" class="col-sm-3 control-label">Etablissement</label>
                               <div class="col-sm-9">
                                    <select list="cookies2" class="form-control" name="etablissement" id="etablissement">   
                                    <option value="Etablissement" selected>Etablissement</option>
                                  </select>
                                </div>
                  </div>
                  <div class="form-group">
                            <label for="inputEmail3" class="col-sm-3 control-label">Département</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="departement" id="departement">
                                      <option value="Département" selected>Département</option>';
                        </select>
                                </div>
                  </div>

                  <div class="form-group">
                    <label for="nom" class="col-sm-3 control-label">Nom</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" name="nom" id="nom" value="<?php echo $nom ?>" placeholder="nom">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="prenom" class="col-sm-3 control-label">Prénom</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" name="prenom" id="prenom" value="<?php echo $prenom ?>" placeholder="prenom">
                    </div>
                  </div>
                  <div class="form-group">
                            <label for="inputEmail3" class="col-sm-3 control-label">Grade</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="grade" id="grade">
                                      <option value="Grade">Grade</option>
                        </select>
                                </div>
                  </div>
                  <div class="form-group">
                            <label for="inputEmail3" class="col-sm-3 control-label">Spécialité</label>
                                <div class="col-sm-9">
                                   <select class="form-control" name="Specialite" id="Specialite">
                                    <option value="Spécialité">Spécialité</option>
                        </select>
                                </div>
                  </div>
                  <div class="form-group">
                    <label for="username" class="col-sm-3 control-label">nom d'utilisateur</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" name="username" onkeyup="usernametest(this)" id="username" value="username" placeholder="nom d'utilisateur">
                    </div>
                  </div>  
                  <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-9">
                      <input type="email" class="form-control" name="email" id="email" onkeyup="emailtest(this)" value="<?php echo $Email ?>" placeholder="Email">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="tele" class="col-sm-3 control-label">telephone</label>
                    <div class="col-sm-9">
                      <input type="text" class="form-control" pattern="[0][6|5|7][0-9]{8}" name="tele" id="tele" value="07561561564" placeholder="Téléphone:[0[6-5-7]XXXXXXXX]">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-offset-6 col-sm-10">
                      <button type="submit" class="btn btn-danger" name="Modifier1">Valider</button>
                    </div>
                  </div>
                </form>
              </div>

              <div class="tab-pane" id="password">
               <form class="form-horizontal" method="POST" action="" onsubmit="return checkall();">
                      <br>
                    <div class="form-group">
                          <label for="password" class="col-sm-4 control-label">Ancien mot de passe</label>
                      <div class="col-xs-4">
                                <input type="password" class="form-control" name="passwordold" id="passwordold" placeholder="Ancien mot de passe" required>
                              </div>
                              <div class="col-xs-4" id="confirmation_pass0">
                              </div>                          
                      </div>  
                      <div class="form-group">
                          <label for="newpassword" class="col-sm-4 control-label">Nouveau mot de passe</label>
                      <div class="col-xs-4">
                                <input type="password" class="form-control" name="newpassword" id="newpassword" placeholder="Nouveau mot de passe" required>
                              </div>            
                      </div>  
                      <div class="form-group">
                          <label for="newpassword1" class="col-sm-4 control-label">Retaper mot de passe</label>
                      <div class="col-xs-4">
                                <input type="password" class="form-control" name="newpassword1" id="newpassword1" placeholder="Retaper mot de passe" required>
                              </div>
                              <div class="col-xs-4" id="confirmation_pass1">
                                <label class="col-sm-12 control-label" id="confirmation_pass13"></label>
                              </div>                      
                      </div>  
                      <div class="form-group">
                          <label for="inputEmail3" class="col-sm-4 control-label"></label>
                            <div class="col-sm-offset-5 col-sm-10">
                      <button type="submit" id="valider1" name="valider1" class="btn btn-danger">Modifier</button>
                            </div>                      
                      </div>
                      
                    </form>               
              </div>
              <!-- /.tab-pane -->
            </div>
            <!-- /.tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->
        </div>
        <!-- /.col -->

<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
      <!-- Modal content-->
      <form name="sform" id="sform" method="POST">
       <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Initiation de la filiere</h4>
      </div>

      <div class="modal-body" >

          <label >Nom draft Filière :</label> 
            <input class="form-control" style="margin-left: 20px; width: 90%; " type="text" name="nomfiliere" id="nomfiliere" placeholder="Nom Filiere">
          
          <label >abréviation :</label> 
            <input class="form-control" style="margin-left: 20px; width: 90%;" type="text" name="abreviation" id="abreviation" placeholder="abréviation" readonly disabled>

          <script>
              $('#nomfiliere').keyup(function(e) 
              {
                var dataString2='nomFil='+ $(this).val() ; 
                      
                  $.ajax
                  ({
                    type: "POST",
                    url: "get_TEST_initiation_filiere.php",
                    data: dataString2,
                    cache: false,
                    success: function(html)
                    {
                      if (html == 1 )
                      {
                        swal(
                          'Attention...',
                          'cette filiere existe deja!',
                          'warning'
                        )
                        $('#nomfiliere').val('');  
                      }
                      else
                      {
                        var x = $('#nomfiliere').val();
                        var y = x.split(" ");
                        var yy1 = y[0];
                        var yy2 = y[1];
                        var yy3 = y[2];
                        if (yy2 != undefined)
                          $('#abreviation').val(yy1[0].toUpperCase()+' '+ yy2[0].toUpperCase());
                        
                        if (yy3 != undefined)
                          $('#abreviation').val(yy1[0].toUpperCase()+' '+ yy2[0].toUpperCase()+' '+ yy3[0].toUpperCase());
                      }
                    }
                  }); 
                }); 

                
            </script> 

      </div>
      <div class="modal-footer">
      <button type="submit" name="exporter" value="exporter" id="exporter" class="btn btn-primary">Suivant</button>
       <button type="button" class="btn btn-default" data-dismiss="modal">Annuler</button>
      </div>

      </form>

    </div>
</div>

      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>CESI-Ingénieurs</b>
    </div>
    <strong>Copyright &copy; 2023-2024</strong> All rights
    reserved.
  </footer>

  
</div>
<!-- ./wrapper -->
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/app.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../dist/js/demo.js"></script>
<script src="../js/sweetalert2.min.js"></script>

<script type="text/javascript">
      $("#universite").change(function()
        {
          var id=$(this).val();
          var dataString = 'id='+ id;
          $.ajax({ 
            type: "POST",
            url: "../LES-GET/get_etablissement.php",
            data: dataString,
            cache: false,
            success: function(html)
            {
              $("#etablissement").html(html);
            }
          });
        });
    $("#etablissement").change(function()
        {
          var id=$(this).val();
          var dataString = 'id='+ id;
          $.ajax({ 
            type: "POST",
            url: "../LES-GET/getDepartement.php",
            data: dataString,
            cache: false,
            success: function(html)
            {
              $("#departement").html(html);
            }
          });
    });

    $('#passwordold').keyup(function(){  
                var query=$(this).val();
          var dataString = 'query='+ query;
          $.ajax({ 
            type: "POST",
            url: "test_mdp.php",
            data: dataString,
            cache: false,
            success: function(html)
            {
              $("#confirmation_pass0").html(html);
            }
          });
      });

      $('#newpassword1').keyup(function()
      {  

          var mdpnew= $('#newpassword').val();  
          var mdpnew1= $('#newpassword1').val();  
          if(mdpnew==mdpnew1)
          {
          $.ajax({ 
            success: function()
            {
              $("#confirmation_pass13").html("MOT DE PASS CONFIRME");
            }
          });
        }
        else
        {
          $.ajax({ 
            success: function()
            {
              $("#confirmation_pass13").html("MOT DE PASS NON CONFIRME");
            }
          });
        }
      });

    </script>
    <script type='text/javascript'>

  function checkall()
  {

    var test=$("#validationtt").text();
    var mdp=$('#newpassword').val();
    var newmdp=$('#newpassword1').val();
    

  if(test=="MOT DE PASS VALIDE" && mdp==newmdp)
  {
  return true;
  }
  else
  {
  return false;
  }

  }

  function testImpossibleop(obj)
  {
    var Pseudo = obj.value;
    var dataString2 = 'Pseudo='+ Pseudo;
        $.ajax({ 
            type: "POST",
            url: "test_mdp.php",
            data: dataString2,
            cache: false,
            success: function(html)
            {
              if (html.trim() == "404") 
              {
              swal(
                  'Erreur...',
                  'Ce Pseudo existe Deja',
                  'error'
                )
                $("#Pseudo").val('<?php echo $Pseudo ?>');
              }
            }
          });
  }
</script>

<script>
    
        $('#Cfiliere').click(function()
        {
          $("#myModal").modal('show');
        });


    function afficher5(objButton) 
    { 
         var testin = objButton.value; 
         document.sform2.matmaty.value=testin;
    } 


    function checkall()
  {

    var cours = document.getElementById('cours');
    var td = document.getElementById('td');
    var tp = document.getElementById('tp');
    var enca = document.getElementById('enca');
    
  if(cours.checked==true || td.checked==true || tp.checked==true || enca.checked==true)
  {
  return true;
  }
  else
  {
  return false;
  }

  }
</script>




</body>
</html>
