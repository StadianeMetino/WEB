<?php
include '../connexion.php';
?>

<?php
session_start();
$code_user = $_SESSION['CODE_USER'];

if (!isset($_SESSION['CODE_USER']) || !isset($_SESSION['Status']) || $_SESSION['Status'] != 'admin') 
{
header('Location: ../login/login.php');
}

  if(isset($_SESSION['CODE_USER']) && $code_user != null){

    $req=($bd->query('SELECT * FROM utilisateurs WHERE id_etudiant="'.$code_user.'" '));
    $sqlEntreprises = "SELECT * FROM entreprise";
    $resultEntreprises = $ma_connexion->query($sqlEntreprises);

    $ress = $req->fetch();
    $prenom = $ress['Prenom'];
    $nom    = $ress['Nom'];
    $Status    = $ress['Status'];
    $Email    = $ress['Email'];
    $id_PromoAnnee    = $ress['id_PromoAnnee'];

  }
  



if (isset($_POST['action']) && $_POST['action'] == 'add') {
    
    // Retrieve form data
    $numSIRET = $_POST['NumSIRET'];
    $nom = $_POST['Nom'];
    $description = $_POST['Description'];
    $nbInterne = $_POST['NbInterne'];

    $sql = "INSERT INTO entreprise (NumSIRET, Nom, Description, NbInterne) VALUES (?, ?, ?, ?)";

    $stmt = $ma_connexion->prepare($sql);
    $stmt->bind_param("issi", $numSIRET, $nom, $description, $nbInterne);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header("Location: entreprises.php");
        exit();
    } else {
        echo "Error adding record: " . $ma_connexion->error;
    }

    $stmt->close();

} elseif (isset($_POST['action']) && $_POST['action'] == 'edit' && isset($_POST['NumSIRET'])) {

    $NumSIRET = $_POST['NumSIRET'];
    $Nom = $_POST['Nom'];
    $Description = $_POST['Description'];
    $NbInterne = $_POST['NbInterne'];

    $sql = "UPDATE entreprise SET 
            Nom = '$Nom',
            Description = '$Description',
            NbInterne = '$NbInterne'
            WHERE NumSIRET = ?"; 

    $stmt = $ma_connexion->prepare($sql);
    $stmt->bind_param("i", $_POST['NumSIRET']); 
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header("Location: entreprises.php");
        exit();
    } else {
        echo "Error updating record: " . $ma_connexion->error;
    }

    // Close statement
    $stmt->close();
}


if(isset($_POST['deleteEntreprise']) && isset($_POST['NumSIRET'])) {

    $NumSIRET = $_POST['NumSIRET'];

    $sql = "DELETE FROM entreprise WHERE NumSIRET = ?";
    $stmt = $ma_connexion->prepare($sql);
    $stmt->bind_param("i", $NumSIRET);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header("Location: entreprises.php");
        exit();
    } else {
        echo "Error deleting entreprise: " . $ma_connexion->error;
    }

    $stmt->close();
}



if(isset($_POST['Quitter']))
{  
  
 // Inialize session
  session_start();
// Delete certain session
  unset($_SESSION['CODE_USER']);
  unset($_SESSION['Status']);
  // Delete all session variables
  // session_destroy();
  session_destroy();
 // Jump to login page
header('Location: ../login/login.php');
}
if (!isset($_SESSION['CODE_USER'])) 
{
header('Location: ../login/login.php');
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Projet des offres | Profil</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">  
  <link rel="stylesheet" type="text/css" href="../css/ionicons.min.css">  
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
  <script src="../js/jquery.js"></script>
  <link rel="stylesheet" type="text/css" href="../css/sweetalert2.min.css">  
  <link rel="stylesheet" type="text/css" href="../DataTables/datatables.min.css"/>
  <script src="../js/sweetalert2.min.js"></script>
  <script type="text/javascript">
  $(function() {
    $('#LesEntreprises').addClass("active");
  });
</script>
</head>
<body class="sidebar-mini wysihtml5-supported skin-blue">
<div class="wrapper">

<?php include("../includes/header.php"); ?>
<?php include("../includes/aside.php"); ?>



<div class="content-wrapper" style="min-height: 1136.3px;">

<section class="content-header">
<h1>
Entreprises
</h1>
</section>

<section class="content">

<div class="box">
<div class="box-header with-border">
<h3 class="box-title">Entreprises</h3>
<div class="box-tools pull-right">
<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="" data-original-title="Collapse">
<i class="fa fa-minus"></i></button>
<button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="" data-original-title="Remove">
<i class="fa fa-times"></i></button>
</div>
</div>


<div class="box-body" style="">



<div class="box-body table-responsive no-padding">

<!-- Add button -->
<div class="top-panel pull-right">
    <a href="javascript:void(0);" class="btn btn-primary" onclick="addEntreprise()">Ajouter une nouvelle Entreprise</a><br><br>
</div>

  <!-- Data list table -->
  <table class="table table-hover" style="width:100%">
      <thead>
          <tr>
              <th>NumSIRET</th>
              <th>Nom</th>
              <th>Description</th>
              <th>NbInterne</th>
              <th>Action</th>
          </tr>
      </thead>

      <tbody>
        
        <?php
          while ($row = $resultEntreprises->fetch_assoc()) {
              $description = strlen($row["Description"]) > 20 ? substr($row["Description"], 0, 20) . "..." : $row["Description"];
              echo "<tr>
                      <td>" . $row["NumSIRET"] . "</td>
                      <td>" . $row["Nom"] . "</td>
                      <td>" . $description . "</td>
                      <td>" . $row["NbInterne"] . "</td>
                      <td>
                          <a href='javascript:void(0);' class='btn btn-warning' onclick='editEntreprise(" . json_encode($row) . ")'>Edit</a>
                          <form method=\"post\">
                              <input type=\"hidden\" name=\"NumSIRET\" value=\"" . $row["NumSIRET"] . "\">
                              <button type=\"submit\" class=\"btn btn-danger\" name=\"deleteEntreprise\" onclick=\"return confirm('Êtes-vous sûr de vouloir supprimer cette entreprise?');\">Delete</button>
                          </form>
                      </td>
                    </tr>";
          }
          ?>


      </tbody>


  </table>
</div>

</div>


</div>

</section>

</div>



<div class="modal fade in" id="modalEntreprise" tabindex="-1" aria-labelledby="addEditOffre" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<form id="entrepriseForm" method="post">

<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">×</span></button>
<h1 class="modal-title fs-5" id="modalEntreprise">Ajouter/modifier une entreprise</h1>
</div>

<div class="modal-body">
    <input type="hidden" name="action" id="action" value="add">
        <div class="mb-3">
            <label for="NumSIRET" class="form-label">NumSIRET</label>
            <input type="number" class="form-control" name="NumSIRET" id="NumSIRET" placeholder="Enter nom le num de siret" required>
        </div>
        <div class="mb-3">
            <label for="Nom" class="form-label">Nom</label>
            <input type="text" class="form-control" name="Nom" id="Nom" placeholder="Enter Nom" required>
        </div>
        <div class="mb-3">
            <label for="Description" class="form-label">Description</label>
            <textarea type="text" class="form-control" name="Description" id="Description" placeholder="Enter Description" required></textarea>
        </div>
        <div class="mb-3">
            <label for="NbInterne" class="form-label">NbInterne</label>
            <input type="number" class="form-control" name="NbInterne" id="NbInterne" placeholder="Enter NbInterne">
        </div>
</div>

<div class="modal-footer">
<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
<button type="submit" class="btn btn-primary" id="submitBtn">Enregistrer</button>
</div>

</form>

</div>
</div>
</div>



<footer class="main-footer">
  <div class="pull-right hidden-xs">
  <b>CESI-Ingénieurs</b>
  </div>
  <strong>Copyright &copy; 2023-2024</strong> All rights
  reserved.
</footer>

  
</div>
<!-- ./wrapper -->
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/app.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../dist/js/demo.js"></script>
<script src="../js/sweetalert2.min.js"></script>
<script type="text/javascript" src="../DataTables/datatables.min.js"></script>

<script type="text/javascript">
  

  function addEntreprise() {

    // Clear previous input values if any
    $('#entrepriseForm')[0].reset();
    $('#NumSIRET').val(null);
    $('#action').val('add'); // Set action to 'add' for adding new entry
    
    // Open modal
    $('#modalEntreprise').modal('show');

  }

  function editEntreprise(rowData) {
      var { NumSIRET, Nom, Description, NbInterne } = rowData;
      $('#NumSIRET').val(NumSIRET);
      $('#Nom').val(Nom);
      $('#Description').val(Description);
      $('#NbInterne').val(NbInterne);
      $('#action').val('edit');
      // Open the modal
      $('#modalEntreprise').modal('show');
  }


</script>



</body>
</html>
