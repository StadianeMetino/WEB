<?php
include '../connexion.php';
?>

<?php
session_start();
$code_user = $_SESSION['CODE_USER'];

if (!isset($_SESSION['CODE_USER']) || !isset($_SESSION['Status']) || $_SESSION['Status'] != 'admin') 
{
header('Location: ../login/login.php');
}

  if(isset($_SESSION['CODE_USER']) && $code_user != null){

    $req=($bd->query('SELECT * FROM utilisateurs WHERE id_etudiant="'.$code_user.'" '));
    $sqlUtilisateurs = "SELECT u.*, p.id_PromoAnnee, p.Nom as NomPromo FROM utilisateurs u, promo_de_l_annee p where u.id_PromoAnnee = p.id_PromoAnnee; ";
    $resultUtilisateurs = $ma_connexion->query($sqlUtilisateurs);

    $ress = $req->fetch();
    $prenom = $ress['Prenom'];
    $nom    = $ress['Nom'];
    $Status    = $ress['Status'];
    $Email    = $ress['Email'];
    $id_PromoAnnee    = $ress['id_PromoAnnee'];

  }
  



if (isset($_POST['action']) && $_POST['action'] == 'add') {
    
    $Nom = $_POST['Nom'];
    $Prenom = $_POST['Prenom'];
    $Status = $_POST['Status'];
    $Email = $_POST['Email'];
    $Mot_de_passe = $_POST['Mot_de_passe'];
    $id_PromoAnnee = $_POST['id_PromoAnnee'];

    $sql = "INSERT INTO utilisateurs (Nom, Prenom, Status, Email, Mot_de_passe, id_PromoAnnee) VALUES (?, ?, ?, ?, ?, ?)";

    $stmt = $ma_connexion->prepare($sql);
    $stmt->bind_param("sssssi", $Nom, $Prenom, $Status, $Email, $Mot_de_passe, $id_PromoAnnee );
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header("Location: utilisateurs.php");
        exit();
    } else {
        echo "Error adding record: " . $ma_connexion->error;
    }

    $stmt->close();

} elseif (isset($_POST['action']) && $_POST['action'] == 'edit' && isset($_POST['id_etudiant'])) {

    $id_etudiant = $_POST['id_etudiant'];
    $Nom = $_POST['Nom'];
    $Prenom = $_POST['Prenom'];
    $Status = $_POST['Status'];
    $Email = $_POST['Email'];
    $Mot_de_passe = $_POST['Mot_de_passe'];
    $id_PromoAnnee = $_POST['id_PromoAnnee'];

    $sql = "UPDATE utilisateurs SET 
            Nom = '$Nom',
            Prenom = '$Prenom',
            Status = '$Status',
            Email = '$Email',
            Mot_de_passe = '$Mot_de_passe',
            id_PromoAnnee = '$id_PromoAnnee'
            WHERE id_etudiant = ?"; 

    $stmt = $ma_connexion->prepare($sql);
    $stmt->bind_param("i", $_POST['id_etudiant']); 
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header("Location: utilisateurs.php");
        exit();
    } else {
        echo "Error updating record: " . $ma_connexion->error;
    }

    // Close statement
    $stmt->close();
}


if(isset($_POST['deleteUtilisateur']) && isset($_POST['id_etudiant'])) {

    $id_etudiant = $_POST['id_etudiant'];

    $sql = "DELETE FROM utilisateurs WHERE id_etudiant = ?";
    $stmt = $ma_connexion->prepare($sql);
    $stmt->bind_param("i", $id_etudiant);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        header("Location: utilisateurs.php");
        exit();
    } else {
        echo "Error deleting utilisateur: " . $ma_connexion->error;
    }

    $stmt->close();
}



if(isset($_POST['Quitter']))
{  
  
 // Inialize session
  session_start();
// Delete certain session
  unset($_SESSION['CODE_USER']);
  unset($_SESSION['Status']);
  // Delete all session variables
  // session_destroy();
  session_destroy();
 // Jump to login page
header('Location: ../login/login.php');
}

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Projet des offres | Profil</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">  
  <link rel="stylesheet" type="text/css" href="../css/ionicons.min.css">  
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../dist/css/skins/_all-skins.min.css">
  <script src="../js/jquery.js"></script>
  <link rel="stylesheet" type="text/css" href="../css/sweetalert2.min.css">  
  <link rel="stylesheet" type="text/css" href="../DataTables/datatables.min.css"/>
  <script src="../js/sweetalert2.min.js"></script>
  <script type="text/javascript">
  $(function() {
    $('#LesUtilisateurs').addClass("active");
  });
</script>
</head>
<body class="sidebar-mini wysihtml5-supported skin-blue">
<div class="wrapper">

<?php include("../includes/header.php"); ?>
<?php include("../includes/aside.php"); ?>



<div class="content-wrapper" style="min-height: 1136.3px;">

<section class="content-header">
<h1>
Utilisateurs
</h1>
</section>

<section class="content">

<div class="box">
<div class="box-header with-border">
<h3 class="box-title">utilisateurs</h3>
<div class="box-tools pull-right">
<button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="" data-original-title="Collapse">
<i class="fa fa-minus"></i></button>
<button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="" data-original-title="Remove">
<i class="fa fa-times"></i></button>
</div>
</div>


<div class="box-body" style="">



<div class="box-body table-responsive no-padding">

<!-- Add button -->
<div class="top-panel pull-right">
    <a href="javascript:void(0);" class="btn btn-primary" onclick="addUtilisateur()">Ajouter un nouveau utilisateur</a><br><br>
</div>

  <!-- Data list table -->
  <table class="table table-hover" style="width:100%">
      <thead>
          <tr>
              <th>Nom</th>
              <th>Prenom</th>
              <th>Status</th>
              <th>Email</th>
              <th>Promo</th>
              <th>Action</th>
          </tr>
      </thead>

      <tbody>
        
        <?php
          while ($row = $resultUtilisateurs->fetch_assoc()) {
              echo "<tr>
                      <td>" . $row["Nom"] . "</td>
                      <td>" . $row["Prenom"] . "</td>
                      <td>" . $row["Status"] . "</td>
                      <td>" . $row["Email"] . "</td>
                      <td>" . $row["NomPromo"] . "</td>
                      <td>
                          <a href='javascript:void(0);' class='btn btn-warning' onclick='editUtilisateur(" . json_encode($row) . ")'>Edit</a>
                          <form method=\"post\">
                              <input type=\"hidden\" name=\"id_etudiant\" value=\"" . $row["id_etudiant"] . "\">
                              <button type=\"submit\" class=\"btn btn-danger\" name=\"deleteUtilisateur\" onclick=\"return confirm('Êtes-vous sûr de vouloir supprimer cet utilisateur?');\">Delete</button>
                          </form>
                      </td>
                    </tr>";
          }
          ?>


      </tbody>


  </table>
</div>

</div>


</div>

</section>

</div>



<div class="modal fade in" id="modalUtilisateur" tabindex="-1" aria-labelledby="addEditUtilisateur" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<form id="utilisateurForm" method="post">

<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-label="Close">
<span aria-hidden="true">×</span></button>
<h1 class="modal-title fs-5" id="modalUtilisateur">Ajouter/modifier un Utilisateur</h1>
</div>

<div class="modal-body">
    <input type="hidden" name="action" id="action" value="add">
    <input type="hidden" name="id_etudiant" id="id_etudiant">
        <div class="mb-3">
            <label for="Nom" class="form-label">Nom</label>
            <input type="text" class="form-control" name="Nom" id="Nom" placeholder="Enter nom etudiant" required>
        </div>
        <div class="mb-3">
            <label for="Prenom" class="form-label">Prenom</label>
            <input type="text" class="form-control" name="Prenom" id="Prenom" placeholder="Enter Prenom" required>
        </div>
        <div class="mb-3">
            <label for="Status" class="form-label">Status</label>
            <input type="text" class="form-control" name="Status" id="Status" placeholder="Enter Status" required>
        </div>
        <div class="mb-3">
            <label for="Email" class="form-label">Email</label>
            <input type="text" class="form-control" name="Email" id="Email" placeholder="Enter Email" required>
        </div>
        <div class="mb-3">
            <label for="NomPromo" class="form-label">NomPromo</label>
            <?php
                $sql = "SELECT id_PromoAnnee, Nom FROM promo_de_l_annee";
                $result = $ma_connexion->query($sql);
                if ($result->num_rows > 0) {
                    echo '<select class="form-control" id="id_PromoAnnee" name="id_PromoAnnee">';
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['id_PromoAnnee'] . "'>" . $row['Nom'] . "</option>";
                    }
                    echo '</select>';
                }
            ?>
        </div>
        <div class="mb-3">
            <label for="Mot_de_passe" class="form-label">Mot_de_passe</label>
            <input type="password" class="form-control" name="Mot_de_passe" id="Mot_de_passe" placeholder="Enter Mot_de_passe" required>
        </div>
</div>

<div class="modal-footer">
<button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
<button type="submit" class="btn btn-primary" id="submitBtn">Enregistrer</button>
</div>

</form>

</div>
</div>
</div>



<footer class="main-footer">
  <div class="pull-right hidden-xs">
  <b>CESI-Ingénieurs</b>
  </div>
  <strong>Copyright &copy; 2023-2024</strong> All rights
  reserved.
</footer>

  
</div>
<!-- ./wrapper -->
<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<!-- AdminLTE App -->
<script src="../dist/js/app.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../dist/js/demo.js"></script>
<script src="../js/sweetalert2.min.js"></script>
<script type="text/javascript" src="../DataTables/datatables.min.js"></script>

<script type="text/javascript">
  

  function addUtilisateur() {

    // Clear previous input values if any
    $('#utilisateurForm')[0].reset();
    $('#id_etudiant').val(null);
    $('#action').val('add'); // Set action to 'add' for adding new entry
    
    // Open modal
    $('#modalUtilisateur').modal('show');

  }

  function editUtilisateur(rowData) {
      var { id_etudiant, Nom, Prenom, Status, Email, id_PromoAnnee } = rowData;
      $('#id_etudiant').val(id_etudiant);
      $('#Nom').val(Nom);
      $('#Prenom').val(Prenom);
      $('#Status').val(Status);
      $('#Email').val(Email);
      // Set selected option based on id_PromoAnnee
         $('#id_PromoAnnee option').each(function() {
            if ($(this).val() == id_PromoAnnee) {
            $(this).prop('selected', true);
            }
        });
      $('#action').val('edit');
      // Open the modal
      $('#modalUtilisateur').modal('show');
  }


</script>



</body>
</html>
