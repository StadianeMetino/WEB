# WEB
Une plateforme web référencant des offres de stage pour des étudiant d'une meme école (CESI).
