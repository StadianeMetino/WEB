<?php
include '../connexion.php';
session_start();

if(isset($_POST['submit']))
{
    $username= mysqli_real_escape_string($ma_connexion,$_POST["username"]);
    $password= mysqli_real_escape_string($ma_connexion,$_POST["password"]);

    $query1="SELECT * FROM utilisateurs WHERE Email = '$username' AND Mot_de_passe = '$password' ";
    $result1 = mysqli_query($ma_connexion, $query1);
    if(mysqli_num_rows($result1) > 0)
    {
      while($row = mysqli_fetch_array($result1))  
        {
          $_SESSION['Status']  = $row['Status'];
          $_SESSION['CODE_USER']  = $row['id_etudiant'];
        }

        if($_SESSION['Status'] != null && $_SESSION['Status'] == 'admin'){
            header('Location: ../Profil/Profil.php');
        }
        elseif ($_SESSION['Status'] != null && $_SESSION['Status'] == 'etudiant') {
            header('Location: ../Etudiant/Espace-Etudiant.php');
        }
    }
    else
    {
     echo"<script>alert('Votre login ou mot de passe invalide !')</script>";
    }

}
  
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Click&Stage | Login</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link href="../css/font-awesome.min.css" rel="stylesheet">
  <!-- Ionicons -->
  <link href="../css/ionicons.min.css" rel="stylesheet">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="../plugins/iCheck/square/blue.css">
</head>
<body class="hold-transition login-page">
<div class="login-box">
  <div class="login-logo">
    <a href="../index.php" class="glyphicon glyphicon-home"><b style="color:#3c8dbc;">Click&</b>-Stage</a>
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">Connectez-vous pour commencer votre session</p>

    <form action="" method="POST">
      <div class="form-group has-feedback">
        <input type="text" class="form-control" placeholder="username" value="username" id="username" name="username" onfocus="if (this.value == 'username'){this.value = '';} ">
        <span class="fa fa-user form-control-feedback"></span>
      </div>
      <div class="form-group has-feedback">
        <input type="password" class="form-control" placeholder="mot de passe" name="password" value="Password" id="password" onfocus="if (this.value == 'Password'){this.value = '';}">
         <span class="glyphicon glyphicon-lock form-control-feedback"></span>
      </div>
      <div class="row">
        <div class="col-xs-7">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox"> Remember Me
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-5">
          <input type="submit" name="submit" class="btn btn-primary btn-block btn-flat" value="Se connecter" />
        </div>  
        <!-- /.col -->
      </div>
    </form>

<br>
    <!-- /.social-auth-links -->
    <!-- <a href="register.php" class="text-center" style="padding-left: 70px;">Enregistrez un nouveau compte</a> -->

  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 2.2.3 -->
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../bootstrap/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="../plugins/iCheck/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>
